# Strategic Plan 2025–2028
## Community Learning Initiative

**Approved by:** Board of Directors, February 2026  
**Version:** 1.0 — Final  
**Review cycle:** Annual, each January

---

## Message from the Executive Director

The past three years have taught us that ambition without execution is a plan, not a strategy.
Our 2022–2024 plan was bold. Some of it worked. Some didn't. This plan is built differently:
fewer priorities, sharper focus, and resources aligned to what we know we can do.

We are entering 2025 with a clearer understanding of where we add value and where we don't.
This plan reflects that clarity.

*— Elena Vasquez, Executive Director*

---

## 1. Organizational Overview

Community Learning Initiative (CLI) is a nonprofit founded in 2008.
We work in early literacy and family engagement across 3 counties.
We currently employ 24 full-time staff and maintain a $4.2M annual operating budget.
Our primary funders are the Regional Education Fund (34%), State Title I pass-through (28%),
and a mix of foundation and individual donors (38%).

---

## 2. Strategic Context

### What we know works
Evidence from our own program data and from the field is unambiguous:
structured literacy instruction, delivered with fidelity, improves reading outcomes.
Our coaching model — where CLI staff work embedded in schools — has
shown stronger results than our previous pull-out tutoring approach.

### What has changed in our environment
- State reading legislation passed in 2024 requires all districts to adopt
  science-of-reading aligned curricula by 2027. This creates demand for CLI's
  coaching expertise.
- The Regional Education Fund has signaled it will shift toward larger,
  multi-year grants to fewer organizations — an opportunity for CLI if we can
  demonstrate scale, a risk if we cannot.
- The COVID recovery funding cliff is real: $800K in pandemic-related grants
  expire in mid-2026 with no replacement secured.

---

## 3. Strategic Priorities 2025–2028

### Priority 1: Deepen our school-embedded coaching model
**Goal:** CLI coaching teams are embedded in 20 schools by 2027 (currently 12).

We will expand our school-embedded coaching from 12 to 20 schools over three years,
prioritizing schools with the highest concentration of below-benchmark readers
(bottom quartile of district data). Expansion will be staged: 4 new schools in 2025,
4 more in 2026, with the final 2 reserved for evaluation and stabilization.

**Budget allocation:** $1.4M/year (33% of operating budget)  
**Staffing:** Requires hiring 6 additional reading coaches (currently 8; target 14)  
**Key assumption:** Sufficient qualified coaches can be recruited at competitive salaries  

### Priority 2: Build and share an open evidence base
**Goal:** CLI publishes a practitioner implementation guide by end of 2026
and presents findings at 3+ national conferences by 2028.

We believe the field needs better implementation knowledge, not more efficacy studies.
We will document our coaching model in sufficient detail that other organizations can
replicate it, and we will disseminate actively — not just publish and wait.

**Budget allocation:** $280K over 3 years (one-time)  
**Staffing:** 0.5 FTE Research and Documentation Coordinator (to be hired)  
**Key assumption:** Research staff and documentation effort can be absorbed alongside delivery  

### Priority 3: Secure long-term funding stability
**Goal:** Reduce dependence on any single funder to below 25% of revenue by 2027;
secure at least $1.5M in multi-year grants by end of 2025.

The Regional Education Fund currently represents 34% of our budget.
That is too much exposure. We will diversify by pursuing federal grants (Title III, Title IV),
corporate foundations, and state education agency contracts.

**Budget allocation:** No direct allocation; Development Director to lead with 20% of time  
**Staffing:** No additional hire planned  
**Key assumption:** The Development Director has capacity to absorb fundraising
expansion alongside existing donor stewardship responsibilities  

---

## 4. What We Are Not Doing

In the interest of focus, this plan explicitly excludes:

- **Family literacy programs** — these were part of the 2022 plan but evidence of
  impact was weaker than expected; we are referring families to partner organizations
- **Direct student tutoring** — CLI is a coaching organization, not a tutoring organization;
  we will not compete with schools and partners in this space
- **Digital product development** — we explored this in 2022–2023; it is not our
  comparative advantage

---

## 5. Goals and Metrics

| Priority | Metric | Baseline (2024) | Target (2027) |
|---|---|---|---|
| School coaching | Number of embedded schools | 12 | 20 |
| School coaching | % students at or above benchmark in coached schools | 58% | 68% |
| Evidence building | Implementation guide published | No | Yes (2026) |
| Evidence building | Conference presentations | 0 | 3 |
| Funding stability | Largest single funder share | 34% | <25% |
| Funding stability | Multi-year grant commitments secured | $0 | $1.5M |

---

## 6. Organizational Health

We commit to:
- Annual staff satisfaction survey, with results shared with the board
- Competitive salary adjustments for all roles below market median by mid-2025
- Reducing average staff turnover from 22% (2024) to below 15% by 2026

---

## 7. Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| Coach recruitment difficulty | High | Partner with 2 university programs for pipeline |
| Funding cliff (2026) | High | Priority 3 addresses this; contingency reserve of 3 months expenses |
| Funder priorities shift | Medium | Diversification reduces exposure |
| New state policy creates compliance burden | Low | Monitor; engage state Ed Agency proactively |
