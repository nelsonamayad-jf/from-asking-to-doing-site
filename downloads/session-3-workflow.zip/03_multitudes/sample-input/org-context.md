# Organizational Context — Community Learning Initiative
**Prepared for:** 2025–2028 Strategy Review  
**Date:** February 2026  
**Prepared by:** James Okonkwo, Operations Coordinator

---

## 1. Current Staffing

| Role | FTE | Notes |
|---|---|---|
| Executive Director | 1.0 | Elena Vasquez, 6 years at CLI |
| Deputy Director | 1.0 | Vacant since October 2025; search ongoing |
| Reading Coaches (school-embedded) | 8.0 | Average tenure: 2.1 years; 2 positions turnover in 2025 |
| Program Coordinators | 3.0 | Support coaching teams |
| Development Director | 1.0 | Joined August 2025; previously at a $1.2M organization |
| Data and Systems Coordinator | 1.0 | James Okonkwo |
| Finance and Operations | 2.0 | |
| Administrative | 2.0 | |
| Research/Documentation Coordinator | 0.0 | Position open; in 2025 strategy plan as 0.5 FTE hire |
| **Total** | **19.0** | Against strategy target of 24 FTE |

**Turnover in 2025:** 4 staff departed (21% — above the sector average of ~18%).
Two reading coaches, one program coordinator, and the former Deputy Director.
Exit interviews cited workload and below-market salaries.

---

## 2. Budget Snapshot (FY2025 Actuals)

| Category | Budgeted | Actual | Variance |
|---|---|---|---|
| Personnel | $2,940,000 | $2,650,000 | +$290,000 (vacant positions) |
| School-embedded coaching | $1,380,000 | $1,210,000 | +$170,000 |
| Documentation and research | $90,000 | $12,000 | +$78,000 (position unfilled) |
| Development and fundraising | $180,000 | $175,000 | ~Break even |
| Administration and operations | $410,000 | $398,000 | ~Break even |
| **Total expenses** | **$4,200,000** | **$3,820,000** | **+$380,000** |
| **Total revenue** | **$4,200,000** | **$4,050,000** | **-$150,000** |

**Net position:** CLI operated at a $230K surplus in FY2025 due primarily to
unfilled positions. This is not a real surplus — it reflects under-delivery, not efficiency.

**COVID funding cliff:** Two grants totaling $800K expire in July 2026.
No replacement has been secured as of February 2026.

---

## 3. Funding Sources (FY2025)

| Funder | Amount | % of Revenue | Grant End |
|---|---|---|---|
| Regional Education Fund | $1,376,000 | 34% | Dec 2027 |
| State Title I pass-through | $1,130,000 | 28% | Annual renewal |
| COVID Emergency Literacy Fund | $480,000 | 12% | July 2026 |
| Federal ESSER (state-administered) | $320,000 | 8% | July 2026 |
| Foundation donors (7 foundations) | $520,000 | 13% | Various |
| Individual donors | $224,000 | 5% | Ongoing |
| **Total** | **$4,050,000** | | |

**Note:** The two COVID/ESSER grants ($800K combined, 20% of revenue) expire July 2026.
The 2025 strategy identifies this as a known risk but the Development Director
has no confirmed replacement pipeline as of this date.

---

## 4. School-Embedded Coaching: Current Status

12 schools currently served across 3 counties.

| County | Schools | CLI Coaches | Avg student benchmark rate |
|---|---|---|---|
| County A | 5 | 3 | 61% |
| County B | 4 | 3 | 57% |
| County C | 3 | 2 | 55% |

**Note on expansion target:** The 2025 strategy plans to grow from 12 to 20 schools
(adding 4 in 2025, 4 in 2026, 2 in 2027). As of February 2026, no new schools have
been added yet. The Deputy Director position (vacant) was expected to lead expansion.

---

## 5. Coach Recruitment Context

The strategy assumes 6 new reading coaches can be hired (total to 14).
Current market conditions:
- Certified reading specialists are in high demand following state legislation
- CLI's current salary range for coaches ($48K–$62K) is below the regional median
  for similarly qualified roles in schools ($55K–$72K)
- University partnerships (mentioned in strategy risk mitigation) have not been
  formally negotiated as of February 2026
- Two coach vacancies from 2025 remain unfilled after 4+ months of active recruitment

---

## 6. Development Function Capacity

The Development Director joined August 2025. Prior organization budget was $1.2M.
Current CLI revenue is $4M. Existing donor portfolio requires:
- 7 active foundation grants with reporting obligations
- State reporting for Title I pass-through
- Individual major donor stewardship (~45 donors at $1K+)

Strategy asks the Development Director to absorb fundraising expansion
(multi-year grants, federal grants, corporate foundations) with 20% of their time,
with no additional development staff planned.

---

## 7. External Environment

- **State legislation (2024):** All districts must adopt science-of-reading curricula by 2027.
  This is a genuine opportunity — districts need coaching support to implement.
  CLI is not yet formally positioned as an implementation partner at the state level.

- **Competitive landscape:** At least 2 other regional nonprofits and 1 national organization
  (Reading Partners) are expanding coaching services in our geography.

- **Policy context:** Federal education funding uncertainty continues.
  Title I renewal is expected but not guaranteed beyond FY2027.
