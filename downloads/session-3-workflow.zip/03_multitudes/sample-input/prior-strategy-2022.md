# Strategic Plan 2022–2024
## Community Learning Initiative

**Approved by:** Board of Directors, January 2022  
**Version:** 2.0 — Final

---

## 1. Strategic Priorities 2022–2024

### Priority 1: Scale our tutoring model to 5,000 students
**Goal:** Provide structured tutoring to 5,000 K–3 students across the region by 2024.

CLI's tutoring program reaches approximately 1,800 students in 2022.
We will scale by training and deploying community volunteer tutors,
partnering with faith communities and civic organizations for recruitment.

**Target:** 5,000 students served by December 2024  
**Budget allocation:** $900K/year  
**Key assumption:** Volunteer pipeline is sustainable at scale  

### Priority 2: Launch family literacy programming
**Goal:** Launch a family literacy initiative reaching 500 families by 2023,
with evidence of impact by 2024.

Research shows that home literacy environment is as predictive of outcomes
as school instruction. We will develop a 10-session family program,
delivered by trained facilitators, with an embedded evaluation.

**Target:** 500 families enrolled by end of 2023; RCT evaluation completed by 2024  
**Budget allocation:** $350K  
**Key assumption:** Families will enroll and complete the 10-session program  

### Priority 3: Develop a digital learning platform
**Goal:** Build a proprietary digital platform for delivering structured literacy
practice to students outside school hours by 2024.

**Target:** Platform launched with 1,000 active users by mid-2024  
**Budget allocation:** $600K (product development, contracted externally)  

### Priority 4: Build school-embedded coaching (pilot)
**Goal:** Pilot school-embedded coaching in 3 schools to test the model.

This is a small investment to explore whether CLI can add value in a coaching role,
distinct from our direct-service tutoring model.

**Target:** 3 schools, 1-year pilot, evaluation completed by December 2023  
**Budget allocation:** $180K  

### Priority 5: Launch a leadership development program for reading coaches
**Goal:** Create a regional professional learning community for literacy coaches
and launch CLI-branded certification by 2023.

**Target:** 50 coaches certified by end of 2023  
**Budget allocation:** $220K  

---

## 2. What Actually Happened (End-of-Plan Retrospective, January 2025)

*Note: This section was added retrospectively to inform the 2025–2028 planning process.*

| Priority | Target | Result | Notes |
|---|---|---|---|
| Tutoring scale to 5,000 | 5,000 students | 2,900 reached (58%) | Volunteer pipeline collapsed post-COVID; difficult to sustain |
| Family literacy | 500 families; RCT | 210 families; no RCT | Enrollment far below target; evaluation not funded |
| Digital platform | 1,000 active users | Platform never launched | $480K spent; vendor contract terminated in 2023 |
| School-embedded coaching | 3 schools pilot | 12 schools (expanded early) | Strongest results; became core of 2025 plan |
| Leadership development | 50 coaches certified | 0 certified | Program never launched due to competing priorities |

---

## 3. Lessons Learned

The 2022–2024 plan tried to do too much. Five priorities with ambitious targets
and a $4M budget meant nothing received sufficient attention.

**What worked:** School-embedded coaching far exceeded its pilot targets and
demonstrated measurable student outcome improvements. This was the one initiative
with a dedicated team, clear theory of change, and consistent funder support.

**What didn't work:**
- Volunteer-dependent models are fragile
- Product development requires different organizational capabilities than program delivery
- Family engagement programs need much longer runways and more intensive outreach
  than assumed — 10 sessions with external facilitators is not sufficient for impact

**What we should have done differently:**
- Set fewer priorities and resourced them fully
- Been more honest with funders about what was and wasn't working
- Exited the digital platform project 12 months earlier ($300K could have been saved)
