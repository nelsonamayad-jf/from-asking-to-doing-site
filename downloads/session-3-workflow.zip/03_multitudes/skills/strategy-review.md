# Skill: /strategy-review

Orchestrate the full two-agent review pipeline and produce
the final formatted report.

---

## Trigger

User runs: `/strategy-review`

---

## Pipeline

```
Input files
    │
    ▼
[RESEARCHER AGENT]
Reads strategy + context files
Builds structured evidence briefing
Saves: output/research-briefing.md
    │
    ▼
── HUMAN CHECKPOINT ──────────────────────────────────
"Here is the research briefing. Review it before the
 reviewer agent proceeds. Is there anything to add or
 correct? Type 'continue' to proceed."
── ────────────────────────────────────────────────────
    │
    ▼
[REVIEWER AGENT]
Reads research briefing only (not original strategy)
Applies 5-lens critique framework
Saves: output/review-findings.md
    │
    ▼
[REPORT ASSEMBLY]
Formats final .docx report
Saves: output/strategy-review-report.docx
    │
    ▼
Output to user
```

---

## Steps

### 1. Initialize

Create `output/audit-log.md` with header:
```
# Audit Log — Strategy Review
Organization: [from org-context.md]
Date: [today]
Operator: /strategy-review skill
─────────────────────────────────────────
```

Print to terminal:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STRATEGY REVIEW PIPELINE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Input files found:
  ✓ strategy-2025.md
  ✓ prior-strategy-2022.md
  ✓ org-context.md

Starting with Researcher agent...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### 2. Run researcher agent

Execute the `/researcher` skill fully.
Wait for it to complete and save `output/research-briefing.md`.

### 3. Human checkpoint

Print the research briefing summary to the terminal (Section 1 only — the strategy map).

Then ask:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CHECKPOINT — Before the Reviewer proceeds
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
The researcher has mapped the strategy and identified:
  • [N] strategic claims
  • [N] core assumptions
  • [N] prior commitments from 2022
  • [N] information gaps

Full briefing: output/research-briefing.md

Does this look right? Any files to add or corrections to make?
Type "continue" to proceed to the Reviewer, or describe what to change.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Wait for user response before proceeding.

### 4. Run reviewer agent

Execute the `/reviewer` skill fully.
Wait for it to complete and save `output/review-findings.md`.

### 5. Assemble the final report

Generate `output/strategy-review-report.docx` using python-docx.

**Report structure:**

```
ORGANIZATIONAL STRATEGY REVIEW
[Organization Name]
[Date]
Prepared using: Researcher + Reviewer Agent Pipeline

────────────────────────────────────────
EXECUTIVE SUMMARY
[3 short paragraphs: what was reviewed, overall picture, top 3 findings]

────────────────────────────────────────
PART 1 — RESEARCH BRIEFING SUMMARY
[Condensed version of research-briefing.md:
 strategy map, prior commitments comparison table, capacity assessment]

────────────────────────────────────────
PART 2 — REVIEW FINDINGS
[All findings from review-findings.md, formatted with severity icons]

────────────────────────────────────────
PART 3 — OVERALL ASSESSMENT
[Reviewer's overall assessment paragraph, verbatim from review-findings.md]

────────────────────────────────────────
APPENDIX — AUDIT LOG
[Full contents of output/audit-log.md]
```

**Formatting:**
- Professional, clean layout
- Severity icons: 🔴 🟡 🟢 (or colored text if emoji not supported)
- Critical findings section in red-bordered box
- Page numbers
- Table of contents

### 6. Final report to user

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STRATEGY REVIEW COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📄 Final report:    output/strategy-review-report.docx
📋 Research brief:  output/research-briefing.md
🔍 Review notes:    output/review-findings.md
📝 Audit log:       output/audit-log.md

Findings summary:
  🔴 Critical:  [N]
  🟡 Moderate:  [N]
  🟢 Minor:     [N]
  ✓  Strengths: [N]

Suggested next steps:
→ "Summarize the critical findings for the board in one page"
→ "Draft a response memo addressing the top 3 concerns"
→ "Compare this review against last year's review"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
