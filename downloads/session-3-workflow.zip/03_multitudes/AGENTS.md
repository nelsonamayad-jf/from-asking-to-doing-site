# AGENTS.md — Session 3 · Workflow

This folder is meant to run standalone in Codex.

Before taking action:

1. Read `CLAUDE.md` in this folder and use it as the session contract.
2. Read the relevant file in `skills/` for the step the user wants to run.

Working defaults:

- Default input folder: `sample-input/`
- Output folder: `output/`
- Preserve the role separation: researcher first, reviewer second
- The reviewer must work from `output/research-briefing.md`, not from the original strategy files
- Maintain `output/audit-log.md` as the trace of what happened

If the user asks for the exact classroom flow, use the orchestration in `skills/strategy-review.md`.
