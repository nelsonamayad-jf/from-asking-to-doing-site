# Session 3 · Workflow

Run a two-agent strategy review with an evidence briefing, a critique pass, and a final report.

## Open This Folder

Use this folder as a standalone project in Claude or Codex:

- Claude: `03_multitudes/CLAUDE.md`
- Codex: `03_multitudes/AGENTS.md`
- Runnable Claude skills: `03_multitudes/.claude/skills/`

The website deck source for this session lives under `website/03_multitudes/`.
It is separate on purpose and is not needed to replicate the session.

## Quickstart

Claude:

```text
/strategy-review
```

or, step by step:

```text
/researcher
/reviewer
```

Codex:

```text
Read CLAUDE.md and skills/strategy-review.md, then run the researcher → reviewer → report pipeline over sample-input/, keeping the reviewer blind to the original strategy document and saving all outputs under output/.
```

## Important Folders

- `sample-input/` — the strategy, prior strategy, and context files
- `output/` — briefing, findings, final report, and audit log
- `skills/` — readable recipes for the researcher, reviewer, and orchestrator
- `.claude/skills/` — Claude slash-command entrypoints

## Expected Output

- `output/research-briefing.md`
- `output/review-findings.md`
- `output/strategy-review-report.docx`
- `output/audit-log.md`
