---
name: researcher
description: "Build the Session 3 evidence briefing from the strategy and context files."
---

# /researcher

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/researcher.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Default to `sample-input/` as the input folder.
