---
name: reviewer
description: "Apply the Session 3 critique framework to the research briefing."
---

# /reviewer

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/reviewer.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Use `output/research-briefing.md` as the sole substantive input.
