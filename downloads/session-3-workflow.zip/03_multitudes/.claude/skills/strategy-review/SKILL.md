---
name: strategy-review
description: "Run the full Session 3 researcher → reviewer → report pipeline."
---

# /strategy-review

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/strategy-review.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Preserve the human checkpoint between the researcher and reviewer stages.
