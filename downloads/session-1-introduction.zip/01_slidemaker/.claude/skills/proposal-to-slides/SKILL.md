---
name: proposal-to-slides
description: "Convert a proposal document (.md, .txt, or .docx) into a polished, on-brand PowerPoint presentation for the Jacobs Foundation. Trigger when the user runs /proposal-to-slides, asks to turn a proposal/research document into slides, a deck, or a presentation within the 01_slidemaker demo, or references input/research-proposal.md or a similar proposal file."
allowed-tools:
  - Read
  - Write
  - Edit
  - Grep
  - Glob
  - Bash
---

# Skill: /proposal-to-slides

Convert a proposal document into a polished PowerPoint presentation.

---

## Trigger

User runs: `/proposal-to-slides [filepath]`

If no filepath is given, ask the user which file to use.

---

## Steps

### 1. Note the brand defaults and locate the template

Before writing any code, take the brand defaults from the **Organization
Defaults** section of `CLAUDE.md`: primary/accent colors, fonts, slide format,
template path, and output folder.

Confirm the internal template exists:
`input/pptx_template/JacobsFoundation-PPT-Template-Master-1-compressed.potx`

This is the Jacobs Foundation master deck (16:9, brand teal, Arial, ~116
layouts). **Build on top of it** — do not invent a visual style from scratch.
Inspect its layouts before generating (see step 4).

### 2. Read the proposal

Read the input file in full. It may be `.md`, `.txt`, or `.docx`.
The sample lives at `input/research-proposal.md`.
If `.docx`, use `pandoc [file] -t plain` to extract the text first
(no Python — Pandoc ships with Quarto).

Identify these elements (they may not be labeled explicitly — infer them):
- **Title** of the proposal
- **Problem or background** — why this work is needed
- **Objectives** — what it aims to achieve (usually a list)
- **Methodology or approach** — how it will be done
- **Timeline or work plan** — key phases or milestones
- **Budget** — totals and main line items
- **Team or partners** — who is involved
- **Expected outcomes** — what success looks like

### 3. Plan the slides

Before generating, print a slide plan to the terminal:
```
Slide plan:
1. Title
2. Agenda
3. Background & Problem
4. Objectives
5. Methodology
6. Timeline
7. Budget Overview
8. Team
9. Expected Outcomes
10. Thank You / Questions
```

Ask: "Does this structure look right, or would you like to adjust it?"
Wait for a response before proceeding.

### 4. Generate the presentation — reproducing the JF brand

**This skill is Python-free and R-free.** Build the deck with `pptxgenjs`
(Node) and reproduce the JF look from the `CLAUDE.md` defaults — do not unpack or edit the
`.potx` XML. Follow the `pptx` skill (`skills/pptx/SKILL.md`):

1. Render the template to images so you can see its layouts and match them:
   ```bash
   soffice --headless --convert-to pdf input/pptx_template/JacobsFoundation-PPT-Template-Master-1-compressed.potx
   pdftoppm -jpeg -r 100 JacobsFoundation-PPT-Template-Master-1-compressed.pdf template-layout
   ```
2. Map each planned slide to a matching JF layout — a title/section look for the
   title and closing slides, a content look for the body slides.
3. Define a `pptxgenjs` slide master that reproduces the brand (teal `#75C4B5`,
   dark teal `#005957`, Arial, logo top-right, slide numbers), then add slides.

If `pptxgenjs` is not installed: `npm install -g pptxgenjs`.

Follow these rules:
- Reproduce the brand colors and fonts in `pptxgenjs`; do not override brand teal/Arial
- Use a dark title/section master for the title and closing slides
- Max 4 bullet points per slide — if the source has more, summarize
- Every slide gets speaker notes (max 80 words, one paragraph)
- Keep the template's slide numbers and logo placement — don't re-add your own
- Remove any leftover template placeholder text (see QA grep in step 6)

### 5. Save output

Save the file as: `output/[proposal-title]-slides.pptx`
Create the `output/` folder if it doesn't exist.

### 6. QA

Convert to images and inspect (no Python — LibreOffice + Poppler):
```bash
soffice --headless --convert-to pdf --outdir output output/*.pptx
rm -f slide-*.jpg
pdftoppm -jpeg -r 150 output/*.pdf slide
```

Use a subagent to visually inspect the slides. Fix any layout issues found.

### 7. Report back

Tell the user:
- How many slides were generated
- Where the file was saved
- Any content from the proposal that didn't fit and was omitted
- Suggest 2–3 follow-up iterations they might want (e.g., "add a risk slide", "make budget a chart")

---

## Example Output

```
✓ Proposal read: 3,200 words
✓ Slide plan confirmed
✓ Generated: output/youth-literacy-program-slides.pptx (10 slides)
✓ Speaker notes: all slides

Omitted: detailed budget breakdown (Table 2) — shown as totals only.
Add it back? Say "add a detailed budget slide."

Suggested next steps:
→ "Add a risk and mitigation slide"
→ "Make the timeline a visual Gantt chart"
→ "Add our logo to the title slide"
```
