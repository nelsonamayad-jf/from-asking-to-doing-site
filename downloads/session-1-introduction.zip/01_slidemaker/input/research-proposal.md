# Youth Literacy Accelerator Program
## Project Proposal — submitted to the Regional Education Fund

**Applicant organization:** Community Learning Initiative  
**Contact:** Dr. Maria Santos, m.santos@cli.org  
**Submission date:** March 2026  
**Funding requested:** $485,000  
**Project period:** 24 months (July 2026 – June 2028)

---

## 1. Background and Problem Statement

Reading proficiency by the end of third grade is one of the strongest predictors of long-term educational and economic outcomes. Yet in our target region, only 52% of third-graders read at grade level — a figure that drops to 38% among children from low-income households and 31% among English language learners.

The COVID-19 pandemic reversed a decade of slow progress. Between 2019 and 2023, average reading scores among second-graders fell by 0.4 standard deviations, and recovery has been uneven. Schools in the region report inadequate access to structured literacy materials, insufficient teacher training in evidence-based reading instruction, and limited capacity for early identification of students who are falling behind.

Current interventions rely heavily on pull-out tutoring delivered by volunteer networks, which lack continuity and are not aligned with classroom instruction. No systematic screening process exists to identify at-risk readers before the end of first grade, when intervention is most effective.

---

## 2. Objectives

This project aims to:

1. Implement universal early literacy screening for all kindergarten and first-grade students in 12 target schools (approximately 2,400 students per year).
2. Build the capacity of classroom teachers to deliver structured literacy instruction aligned with the science of reading.
3. Establish a tiered intervention system connecting early screening results to appropriate support levels.
4. Produce an open-access implementation guide to enable replication in other districts.

---

## 3. Methodology and Approach

### 3.1 Early Screening

We will adopt the DIBELS 8th Edition screening battery, administered three times per year (fall, winter, spring) by trained classroom teachers. Screening data will be entered into a purpose-built dashboard accessible to teachers, school coordinators, and district administrators. Students scoring below the 25th percentile will be automatically flagged for Tier 2 support; those below the 10th percentile will be referred for comprehensive assessment.

### 3.2 Teacher Professional Development

A 30-hour structured professional development program will be delivered across three phases:
- **Phase 1 (Months 1–4):** Foundations of structured literacy and the science of reading (10 hours, in-person workshops)
- **Phase 2 (Months 5–8):** Classroom implementation with instructional coaching (12 hours, in-classroom support)
- **Phase 3 (Months 9–12):** Data use, progress monitoring, and instructional adjustment (8 hours, hybrid)

All materials will be developed in partnership with the Regional Teacher Training Institute and licensed under Creative Commons for free distribution.

### 3.3 Tiered Intervention

- **Tier 1:** High-quality core instruction for all students (teachers trained under 3.2)
- **Tier 2:** Small-group intervention (3–5 students) delivered 3×/week by trained reading coaches
- **Tier 3:** Individualized daily intervention with certified reading specialists

### 3.4 Implementation Guide

A detailed open-access guide will document all tools, protocols, training materials, and lessons learned. It will be published under Creative Commons and disseminated through the National Literacy Network.

---

## 4. Timeline

| Phase | Activities | Months |
|-------|-----------|--------|
| Preparation | Hire staff, adapt materials, establish MOU with schools | 1–3 |
| Baseline screening | Administer fall DIBELS across all 12 schools | 4 |
| PD Phase 1 | Foundations workshops for all teachers | 4–6 |
| Intervention launch | Tier 2 and Tier 3 groups formed and activated | 5–6 |
| PD Phase 2 | In-classroom coaching | 7–10 |
| Mid-line screening | Winter and spring DIBELS rounds | 8, 12 |
| PD Phase 3 | Data use and adjustment | 10–13 |
| Year 2 continuation | Repeat screening and intervention cycle | 13–24 |
| Documentation | Compile implementation guide | 20–24 |
| Dissemination | Publish guide, present findings | 23–24 |

---

## 5. Budget

| Category | Year 1 | Year 2 | Total |
|----------|--------|--------|-------|
| Personnel (Project Director, 2 Reading Coaches, Coordinator) | $148,000 | $152,440 | $300,440 |
| Professional development delivery | $38,000 | $18,000 | $56,000 |
| Screening tools and materials | $22,000 | $8,000 | $30,000 |
| Technology (dashboard, devices) | $28,000 | $6,000 | $34,000 |
| Evaluation and data analysis | $18,000 | $18,000 | $36,000 |
| Dissemination and publication | $0 | $12,000 | $12,000 |
| Indirect costs (15%) | $9,600 | $7,260 | $16,860 |
| **Total** | **$263,600** | **$221,700** | **$485,300** |

---

## 6. Project Team

**Dr. Maria Santos, Project Director** — 15 years in literacy program design; formerly Director of Curriculum at Riverside Unified School District. Will oversee all project activities and serve as primary contact.

**James Okonkwo, Data and Systems Coordinator** — specializes in educational data systems and progress monitoring. Will manage the screening dashboard and produce quarterly data reports.

**Reading Coaches (2 FTE)** — to be recruited from certified reading specialists with structured literacy certification. Will deliver Tier 2 and Tier 3 interventions and provide instructional coaching.

**Regional Teacher Training Institute (partner)** — will co-design and co-deliver the professional development program. Co-signed letter of commitment included in Appendix A.

---

## 7. Expected Outcomes

By the end of Year 1:
- 100% of kindergarten and first-grade students screened (approx. 2,400)
- 95% of classroom teachers complete Phase 1 and 2 professional development
- 80% of identified Tier 2 students receiving intervention within 6 weeks of screening
- Baseline data collected for evaluation

By the end of Year 2:
- 65% of students who entered the program below benchmark achieve grade-level reading by end of Grade 1 (compared to 38% historical average)
- Implementation guide published and available for download
- Findings presented at 2 regional conferences
- Replication in at least 2 additional districts initiated

---

## 8. Evaluation

An independent evaluation will be conducted by Dr. Ana Ribeiro at State University. The evaluation will use a pre-post design with a matched comparison group from similar schools not receiving the intervention. Primary outcome: DIBELS Oral Reading Fluency scores at end of Grades K and 1. Secondary outcomes: teacher knowledge and instructional practice (observation rubric), and parent engagement.

Quarterly progress reports will be submitted to the funder. A final evaluation report will be submitted 60 days after project close.
