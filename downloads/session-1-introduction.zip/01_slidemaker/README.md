# Session 1 · Slidemaking

Turn one proposal document into an on-brand presentation.

## Open This Folder

Use this folder as a standalone project in Claude or Codex:

- Claude: `01_slidemaker/CLAUDE.md`
- Codex: `01_slidemaker/AGENTS.md`
- Runnable Claude skill: `01_slidemaker/.claude/skills/proposal-to-slides/SKILL.md`

The website deck source for this session lives under `website/01_slidemaker/`.
It is separate on purpose and is not needed to replicate the session.

## Quickstart

Claude:

```text
/proposal-to-slides input/research-proposal.md
```

Codex:

```text
Read CLAUDE.md and .claude/skills/proposal-to-slides/SKILL.md, then turn input/research-proposal.md into an on-brand .pptx and save it in output/.
```

## Important Folders

- `input/` — sample proposal, template, and reference materials
- `output/` — generated decks
- `assets/` — images used by the teaching deck
- `skills/` — supporting presentation skill documentation

## Expected Output

- A `.pptx` deck in `output/`
- Speaker notes on every slide
- The Jacobs Foundation template and defaults from `CLAUDE.md`
