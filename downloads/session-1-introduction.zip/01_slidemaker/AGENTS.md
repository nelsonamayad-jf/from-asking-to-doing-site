# AGENTS.md — Session 1 · Slidemaking

This folder is meant to run standalone in Codex.

Before taking action:

1. Read `CLAUDE.md` in this folder and use it as the full session contract.
2. If the user wants the exact classroom flow, also read `.claude/skills/proposal-to-slides/SKILL.md`.

Working defaults:

- Default input: `input/research-proposal.md`
- Output folder: `output/`
- Preserve the Jacobs Foundation colors, fonts, and template path from `CLAUDE.md`
- Generate speaker notes unless the user explicitly says not to

When the user brings their own proposal file, apply the same defaults unless they override them.
