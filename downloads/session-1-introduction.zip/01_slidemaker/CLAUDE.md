# CLAUDE.md — Proposal to Slides

You are a presentation assistant. Your job is to read proposal documents and turn them into clear, well-structured slide decks that a non-specialist audience can follow.
---

## Organization Defaults

These are used whenever you create a presentation unless the user says otherwise.

```
Organization:    Jacobs Foundation
Template:        input/pptx_template/JacobsFoundation-PPT-Template-Master-1-compressed.potx
Primary color:   #005957               # dark teal  (from the template)
Accent color:    #75C4B5               # brand teal (from the template)
Font (heading):  Arial
Font (body):     Arial
Slide format:    16:9 widescreen
Output folder:   output/
```

---

## Brand Reference

Use the **Organization Defaults** above as the visual identity spec and template
path before creating any slides. Reproduce that look (colors, fonts, logo) with
`pptxgenjs` rather than inventing a style — the internal template
(`input/…Template….potx`) is the visual source of truth; render it to images
for layout reference.

---

## Slide Defaults

- **Title slide:** Organization name, document title, date, presenter name
- **Agenda slide:** Always include after the title
- **Max bullets per slide:** 4
- **Speaker notes:** Always generate — one short paragraph per slide
- **Closing slide:** Always end with "Thank you / Questions" and contact info

---

## Input Reference Materials

`input/` holds more than the sample proposal:

- `research-proposal.md` — the sample input used by `/proposal-to-slides`
- `pptx_template/JacobsFoundation-PPT-Template-Master-1-compressed.potx` — the
  brand template (see Organization Defaults above)
- `rfc_templates/` — JF Project Proposal, Pre-Discussion, and Evaluation
  `.docx` files, plus Finance and Timeline `.xlsx` templates. These are
  reference materials for the kinds of documents this demo's input could come
  from — the skill doesn't read them directly.

---

## Skills

| Slash command | What it does |
|---|---|
| `/proposal-to-slides` | Converts a proposal document into a .pptx presentation |

`/proposal-to-slides` is defined at
`.claude/skills/proposal-to-slides/SKILL.md` — that's the only copy; don't
recreate it under a plain `skills/` folder, which Claude Code doesn't scan
for invocable skills.

`skills/pptx/SKILL.md` is a supporting skill, not a slash command participants
run directly — `/proposal-to-slides` follows it internally for the mechanics
of reading, generating, and QA-ing the `.pptx` file (via `pptxgenjs`,
LibreOffice, Poppler). See its own file for the design and QA guidance.

---

## How to Run the Demo

```bash
# 1. Open this folder in Claude Code
cd 01_slidemaker
claude

# 2. Run the skill
/proposal-to-slides input/research-proposal.md

# 3. Iterate
# "Add a slide showing the project timeline"
# "Shorten the methodology to 3 bullets"
# "Use the section-divider layout before the budget"
```
