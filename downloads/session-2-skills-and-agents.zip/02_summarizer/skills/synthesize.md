# Skill: /synthesize

Read each input file and produce a structured per-file summary.
These summaries are the building blocks for the final report.

---

## Trigger

User runs: `/synthesize`

Requires: `output/manifest.md` must exist (run `/collect` first).

---

## Steps

### 1. Read the manifest

Read `output/manifest.md`. Get the file list and content type for each.

### 2. Process each file

For each file in the manifest, use the appropriate summarization prompt
based on its content type:

---

**meeting-notes:**
```
Read these meeting notes. Extract:
- Date and attendees (if mentioned)
- Decisions made (explicit agreements or resolutions)
- Action items (tasks assigned, with owner and deadline if stated)
- Key discussion points (no more than 5 bullets)
- Open questions or unresolved issues
```

**field-report:**
```
Read this field report. Extract:
- Location, date, and observer (if mentioned)
- Key observations (what was seen/found)
- Quantitative figures (counts, percentages, measurements)
- Anomalies or unexpected findings
- Recommended follow-up actions
```

**literature:**
```
Read these literature notes. Extract:
- Sources cited (author, year, title)
- Key findings relevant to the project
- Methodological notes (study design, sample size, context)
- Gaps or limitations noted
- Direct implications for the current work
```

**data:**
```
Read this data file. Extract:
- What the data measures (variables, units)
- Sample size and coverage (who/what/when)
- Key summary statistics or findings
- Data quality issues (missing data, outliers noted)
- What questions this data can and cannot answer
```

**administrative:**
```
Read this document. Extract:
- Document type and purpose
- Key figures, dates, or constraints
- Parties involved
- Notable terms, conditions, or risks
- Action items or decisions required
```

**correspondence:**
```
Read this correspondence. Extract:
- Date, sender, recipient
- Main request or message
- Commitments made
- Follow-up required
- Tone and urgency level
```

---

### 3. Flag uncertainty

At the end of each summary, add a `⚠ Flagged` section if:
- Important information is missing or ambiguous
- The document contradicts another document in the manifest
- A key claim is unverified or the source is unclear

### 4. Save summaries

Save each summary as `output/summaries/[filename]-summary.md`.

Create the folder if it doesn't exist.

### 5. Report back

```
✓ Synthesized: [N] files
✓ Summaries saved to output/summaries/
⚠ Flagged items: [N — list each briefly]

Run /report to assemble the final document.
```

---

## Important

Do not try to reconcile contradictions between files at this stage.
Just flag them. The reconciliation happens in `/report`.
