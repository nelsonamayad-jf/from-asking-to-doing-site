# Skill: /summarizer

Run the full pipeline: collect → synthesize → report.

This is the "one command" shortcut. For teaching, run the three skills
separately so participants see each step.

---

## Trigger

User runs: `/summarizer [optional: folder path]`

Default folder: `sample-inputs/`

---

## Steps

Run in sequence:

1. Run `/collect` — scan, classify, save manifest
2. Run `/synthesize` — summarize each file, save summaries
3. **Pause** before `/report` — show the proposed structure and wait for user confirmation
4. Run `/report` — assemble and write the final document

---

## Progress display

Print a progress header before each step:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STEP 1 / 3 — COLLECTING FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Final summary

After all three steps complete:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PIPELINE COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Files processed:  [N]
✓ Summaries:        output/summaries/
✓ Final report:     output/summary-report.docx
⚠ Flagged items:    [N] — check the last section

Total time: ~[X] minutes
```
