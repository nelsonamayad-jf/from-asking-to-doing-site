# Skill: /report

Assemble all per-file summaries into a single formatted Word (.docx) report.

---

## Trigger

User runs: `/report`

Requires: `output/summaries/` must contain at least one summary file.
(Run `/collect` then `/synthesize` first, or use `/summarizer` for all three.)

---

## Steps

### 1. Read all summaries

Read every file in `output/summaries/`. Also read `output/manifest.md`
for metadata (dates, types, sources).

### 2. Propose report structure

Before writing anything, print a proposed structure to the terminal:

```
PROPOSED REPORT STRUCTURE
─────────────────────────────────────
1. Executive Summary
2. Key Decisions and Action Items
3. Field Observations and Data
4. Evidence from Literature
5. Administrative and Budget Notes
6. Flagged Items Requiring Review
─────────────────────────────────────
Does this structure work for your report?
Adjust, add, or remove sections before I proceed. (Reply "go" to confirm.)
```

**Wait for user confirmation before proceeding.**

### 3. Synthesize across files

Once confirmed, synthesize across summaries:

- **Merge** related points from multiple files under a single section
- **Surface contradictions** explicitly — do not silently pick one version
- **Attribute sources** — every substantive claim should note its source file
- **Highlight consensus** — when multiple sources agree, say so
- **Preserve uncertainty** — if something is unclear, say so rather than guessing

### 4. Write the report

Use the docx skill to generate a Word document.
Install if needed: `pip install python-docx --break-system-packages`

**Report structure:**

```
[TITLE]
Summary Report — [project or folder name]
Generated: [today's date]
Sources: [N files, date range]

1. Executive Summary
   2–3 paragraphs. What do decision-makers need to know?

2. [Section per content type or theme]
   Narrative synthesis, not bullet dumps.
   Source attribution in parentheses: (meeting-notes, 2026-01-15)

[Last section] Flagged Items Requiring Review
   Bulleted list of contradictions, gaps, or unverified claims.
   Each item: what was flagged, which files, what to do about it.
```

**Formatting rules:**
- Use numbered headings (1. 2. 2.1)
- Body text: 11pt, 1.15 line spacing
- Headings: bold, dark blue (#1B4F72)
- Flagged items: yellow highlight
- Page numbers in footer
- Max 10 pages

### 5. Save output

Save as: `output/summary-report.docx`

### 6. Report back

```
✓ Report generated: output/summary-report.docx
✓ [N] pages | [N] sections | [N] source files

⚠ Flagged items: [N] — review the last section before distributing.

Suggested follow-up:
→ "Add a recommendations section"
→ "Translate the executive summary to Spanish"
→ "Export as PDF"
```
