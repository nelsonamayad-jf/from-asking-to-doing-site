# Skill: /collect

Scan the input folder, classify each file, and produce a manifest that
downstream skills can use.

---

## Trigger

User runs: `/collect [optional: folder path]`

Default folder: `sample-inputs/`

---

## Steps

### 1. List all files

```bash
ls -lh [folder]
```

List every file. Note the filename, extension, and file size.

### 2. Classify each file

For each file, determine its **content type** based on filename, extension,
and a quick read of the first 20 lines:

| Content type | Description | Examples |
|---|---|---|
| `meeting-notes` | Notes or transcript from a meeting or call | agenda, minutes, transcript |
| `field-report` | Observations, site visit notes, or field data | field notes, visit report |
| `literature` | Academic or policy references, literature summaries | papers, reviews, annotated bib |
| `data` | Quantitative data, statistics, survey results | CSV, Excel, table-heavy docs |
| `administrative` | Budgets, contracts, timelines, org charts | budget sheet, work plan |
| `correspondence` | Emails, letters, memos | email thread, memo |
| `unknown` | Cannot be classified | anything else |

### 3. Extract metadata

For each file, extract (where available):
- Date (from filename, header, or content)
- Author or source
- One-sentence description of contents

### 4. Flag issues

Flag any files that:
- Are empty or nearly empty (< 100 words)
- Are duplicates of another file
- Cannot be read (binary, corrupted)
- Have ambiguous content type

### 5. Print the manifest

Print a clean manifest to the terminal:

```
INPUT MANIFEST
──────────────────────────────────────────────────────
# │ File                        │ Type           │ Date       │ Notes
──┼─────────────────────────────┼────────────────┼────────────┼────────────
1 │ 01-meeting-notes.md         │ meeting-notes  │ 2026-01-15 │ Project kickoff
2 │ 02-field-data.md            │ data           │ 2026-02-03 │ Baseline survey results
3 │ 03-literature-notes.md      │ literature     │ 2026-01-20 │ Key studies on intervention
──────────────────────────────────────────────────────
Total: 3 files | 0 flagged

Ready for /synthesize
```

### 6. Save manifest

Save the manifest as `output/manifest.md` for use by `/synthesize` and `/report`.

---

## What to tell the user

```
✓ Scanned: [N] files in [folder]
✓ Classified: [breakdown by type]
⚠ Flagged: [N files with issues, or "none"]

Manifest saved to output/manifest.md
Run /synthesize to process each file.
```
