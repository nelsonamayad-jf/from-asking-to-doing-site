# Instructional Coaching — Evidence Review Notes
**Compiled by:** Maria Santos
**Date:** February 28, 2026
**Purpose:** Inform coach deployment model and fidelity expectations

---

## 1. Joyce & Showers (2002) — Coaching and Classroom Transfer

**Full citation:** Joyce, B., & Showers, B. (2002). *Student achievement through
staff development* (3rd ed.). Association for Supervision and Curriculum Development.

**Key findings:**
The original coaching model distinguishes transfer effects across professional
development conditions:
- Theory alone: ~10% transfer to classroom practice
- Theory + demonstration: ~30% transfer
- Theory + demonstration + practice with feedback: ~60% transfer
- Theory + demonstration + practice + coaching in the classroom: ~95% transfer

**Implication for project:** Justifies embedding coaches at schools rather than
delivering PD as standalone workshops. The Phase 1 PD sessions (March–April) will
produce limited transfer unless followed by in-classroom coaching — as planned.

**Caveat:** These percentages are widely cited but based on observational estimates,
not controlled trials. They should be treated as directional, not precise.

---

## 2. Knight (2007) — Instructional Coaching Model

**Full citation:** Knight, J. (2007). *Instructional coaching: A partnership approach
to improving instruction.* Corwin Press.

**Relevant components for our model:**
- Partnership approach: coach and teacher as equals, not evaluator and evaluatee
- Focus on a small number of high-leverage practices at a time
- Video-based reflection preferred over observation notes alone
- Goal-setting with teachers using student outcome data

**Implication for project:** Our coaches should frame sessions as collaborative —
not as monitoring visits. This is particularly important at School A where teachers
raised workload concerns in the kickoff meeting.

⚠ **Flag:** Our current coaching model does not include video-based reflection due
to consent logistics. Knight's evidence base emphasizes this component. We should
note this as a fidelity gap in the evaluation plan.

---

## 3. Blazar & Kraft (2015) — Coach Caseloads and Effectiveness

**Full citation:** Blazar, D., & Kraft, M.A. (2015). Exploring mechanisms of effective
teacher coaching: A tale of two cohorts. *Educational Evaluation and Policy Analysis,
37*(4), 542–566.

**Key finding:** Coach effectiveness is strongly moderated by caseload. In their study,
coaches with more than 15 teachers showed significantly reduced impact (effect sizes
dropped by approximately 40% above that threshold).

**Direct implication:** Each of our two coaches is responsible for 15–20 teachers
across Tier 2 and Tier 3 support. This places them at the upper edge of the effective
range. Hiring a third coach would reduce average caseloads to ~10 teachers each —
well within the effective range.

⚠ **Flag:** This finding directly supports the budget amendment request for a third
coach. Include this citation in the budget amendment narrative.

---

## 4. Matsumura et al. (2010) — Coaching Dosage

**Full citation:** Matsumura, L.C., Garnier, H.E., Correnti, R., Junker, B., &
Bickel, D.D. (2010). Investigating the effectiveness of a comprehensive literacy
coaching program in schools with high teacher mobility. *Elementary School Journal,
111*(1), 35–62.

**Key finding:** Teachers who received high-dosage coaching (10+ sessions per year)
showed significantly greater improvements in instructional quality and student outcomes
than low-dosage recipients (fewer than 5 sessions). The relationship was dose-dependent.

**Implication for project:** Our current model specifies "regular coaching visits"
without a minimum dosage. We should define a minimum of 8–10 sessions per teacher
per year to align with the evidence base.

**Action needed:** Revise coaching protocol to specify minimum visit frequency.

---

## Summary: Gaps in Current Coaching Model

| Gap | Evidence Base | Recommended Action |
|---|---|---|
| No video reflection component | Knight (2007) | Note as fidelity limitation; not feasible to add |
| Dosage not specified | Matsumura et al. (2010) | Add minimum 8 sessions/year to protocol |
| Caseload risk (>15 teachers) | Blazar & Kraft (2015) | Support budget amendment for 3rd coach |
