# Evaluation Design — Methods and Framework Notes
**Compiled by:** Maria Santos
**Date:** March 10, 2026
**Purpose:** Document the evaluation approach and its limitations ahead of
the baseline data collection

---

## Overview

The project uses a pre-post comparison design with two participating schools.
There is no randomized control group. The evaluation aims to:

1. Document implementation fidelity (were the skills delivered as designed?)
2. Measure student literacy growth from baseline to mid-year and end-of-year
3. Identify factors associated with differential growth across tiers and schools

---

## Design Choice: Why Not a Randomized Trial

A randomized controlled trial (RCT) was not feasible for two reasons:
- The Regional Education Fund required both project schools to participate from
  the start — randomizing one school to a control condition was not acceptable
- Sample size (487 students) is too small to power a school-level RCT

The evaluation uses a single-group pre-post design with historical benchmarks
as the comparison reference. Effect sizes will be reported as Cohen's d comparing
pre-post gains to expected growth norms from the DIBELS national sample.

---

## 1. Shadish, Cook & Campbell (2002) — Quasi-Experimental Design

**Full citation:** Shadish, W.R., Cook, T.D., & Campbell, D.T. (2002).
*Experimental and quasi-experimental designs for generalized causal inference.*
Houghton Mifflin.

**Relevant cautions for our design:**
- Pre-post designs without a control group cannot rule out maturation effects
  (students would have grown anyway) or history effects (other events during
  the intervention period)
- Regression to the mean is a particular risk when participants are selected
  based on low scores (as Tier 2 and 3 students are)

**How we will address this:**
- Compare growth rates to DIBELS normative growth expectations
- Report effect sizes alongside raw score gains
- Acknowledge maturation and regression-to-mean as limitations in the report

---

## 2. What Counts as Evidence of Effect?

Our benchmarks for claiming the intervention worked:

| Indicator | Threshold for "positive result" |
|---|---|
| Tier 2 students at benchmark (end of year) | ≥ 65% |
| Tier 3 students exiting to Tier 2 | ≥ 40% |
| Effect size (Cohen's d, Tier 2 pre-post) | ≥ 0.40 |
| Implementation fidelity | ≥ 80% of sessions delivered as planned |

These thresholds were agreed with the Regional Education Fund at kickoff and
are documented in the grant agreement (Section 4.2).

---

## 3. Shadish et al. on Regression Discontinuity (for future reference)

The project does not use regression discontinuity (RD) in Year 1, but if a
comparison school can be identified in Year 2 with similar demographics and
the same DIBELS benchmark cutoff, an RD design would strengthen causal claims
considerably. Note for future evaluation planning.

---

## 4. Fidelity Measurement — What We Will Track

Based on O'Donnell (2008) and Dane & Schneider (1998):

| Fidelity dimension | How we measure it |
|---|---|
| Adherence | Coach observation logs (% of protocol steps completed) |
| Dosage | Attendance records (sessions delivered vs. planned) |
| Quality | Coaching observation rubric (quarterly, by Maria) |
| Participant responsiveness | Teacher surveys (mid-year and end-of-year) |

⚠ **Gap identified:** We do not have a formal differentiation measure — we cannot
confirm that Tier 3 sessions are meaningfully more intensive than Tier 2 beyond
group size. This is a recognized limitation.

---

## Summary of Key Evaluation Risks

| Risk | Severity | Mitigation |
|---|---|---|
| Regression to mean inflates gains | Medium | Compare to DIBELS growth norms |
| Maturation confound | Medium | Acknowledge as limitation |
| Low fidelity at School B | High | Coaching monitoring visits, attendance tracking |
| Missing data (absent students) | Low | Current missing rate is 4.3% — acceptable |
| No differentiation measure for tier intensity | Low | Flag as limitation in report |
