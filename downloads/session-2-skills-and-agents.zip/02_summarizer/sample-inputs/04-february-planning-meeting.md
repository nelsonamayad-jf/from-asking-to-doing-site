# PD Planning & Dashboard Demo — Meeting Notes
**Date:** February 12, 2026
**Format:** Virtual (Zoom)
**Facilitator:** Dr. Maria Santos
**Attendees:** Maria Santos, James Okonkwo, Fatima Al-Rashid (RTTI),
Principal Adaora Eze (School A), Principal Robert Tan (School B)

---

## Agenda

1. Phase 1 PD schedule — revised draft review
2. Dashboard demo and feedback
3. Coach deployment update
4. Open items from January kickoff

---

## Discussion Notes

### 1. PD Schedule

Fatima presented the revised Phase 1 schedule. Saturday morning sessions (8am–12pm)
replace the original weekday afternoon slots. Both principals confirmed acceptance.
Teachers at School A who raised workload concerns have been briefed — no further
objections reported.

**Decision:** Saturday PD schedule approved. Dates confirmed:
- Saturday March 7 — Phonemic Awareness and Phonics foundations (full day)
- Saturday March 21 — DIBELS administration and scoring practicum
- Saturday April 4 — Differentiated instruction: Tier 2 and Tier 3 planning

Maria noted RTTI will arrange childcare support on those days (budgeted). No
substitute coverage needed for Saturday sessions.

### 2. Dashboard Demo

James demonstrated the screening dashboard. Highlights:
- Auto-flagging works correctly (tested with dummy data)
- School-level and teacher-level views functional
- Export to Excel confirmed working
- Spanish-language names display correctly (UTF-8 encoding confirmed)

**Feedback:**
- Principal Eze: wants a print view for data team meetings — James to add print
  stylesheet by March 1
- Principal Tan: requested ELL flag visible on student detail screen — James to
  implement before baseline screening

**Issue outstanding:** School A IT has not confirmed SIS integration with the
dashboard. Principal Eze to escalate internally. Deadline: February 20, or James
will implement manual data transfer as fallback.

### 3. Coach Deployment

Two reading coaches confirmed: Ms. Yolanda Pierce (School A) and Mr. Samuel
Adeyemi (School B). Both completed RTTI onboarding last week.

**Risk flagged by Maria:** Original projections assumed 50–60 Tier 3 students
across both schools. If baseline screening returns significantly more, two coaches
will be under-resourced. James to model three staffing scenarios before March meeting.

**Action item:** James to model scenarios for 60 / 70 / 80 Tier 3 students — share
by February 26.

### 4. Open Items Resolved from January

- ✅ IDEL/DIBELS ELL accommodation: Maria confirmed authorization received.
  IDEL will be used for eligible ELL students at School B. Documentation filed.
- ✅ Updated project timeline: sent by James on January 22.
- ⏳ Paper-based fallback for data entry: still under review. One classroom at
  School A (22 students) will likely need paper forms; James will handle entry.

---

## Action Items

| Item | Owner | Due |
|---|---|---|
| Print view for dashboard | James | Mar 1 |
| ELL flag on student detail screen | James | Mar 1 |
| SIS integration decision | Principal Eze / James | Feb 20 |
| Staffing scenario modeling (60/70/80 Tier 3) | James | Feb 26 |

---

## Next Meeting

March 5, 2026 — virtual, 9:30–11am
Focus: staffing scenario review, PD logistics, baseline screening prep
