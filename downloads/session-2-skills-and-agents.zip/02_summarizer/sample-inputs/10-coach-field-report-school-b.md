# Field Report — Reading Coach, School B
**Coach:** Samuel Adeyemi
**School:** School B
**Reporting period:** October 27 – December 19, 2026 (Weeks 1–8)
**Submitted to:** Dr. Maria Santos
**Date submitted:** January 7, 2027

---

## Overview

This report covers the first 8 weeks of Tier 2 and Tier 3 intervention at School B.
Overall, the intervention is running and students are making gains. However, two
operational issues significantly disrupted delivery during this period and must be
addressed before Q2.

---

## What Is Working

**Student engagement:** Students in all groups are engaged during sessions. The
structured routines (warm-up, explicit instruction, practice, exit check) are
working well. Students who initially resisted group pull-out are now coming willingly.

**Teacher communication:** Five of the seven teachers whose students are in
intervention have been receptive to weekly check-ins. Two teachers with Tier 3
students (Ms. Osei and Mr. Vargas) have asked for coaching on how to reinforce
DIBELS skills during whole-class instruction — this is exactly the kind of teacher
engagement we hoped for.

**IDEL use for ELL students:** The switch to IDEL for 38 Spanish-dominant students
is working smoothly. No logistical barriers after the first week.

---

## Issues

### Issue 1 — Classroom Conflicts (Weeks 3–4)

During Weeks 3 and 4, two teachers at School B (Ms. Fontaine, Grade K, and
Mr. Reyes, Grade 1) were pulling Tier 2 students out of intervention sessions
for test preparation activities. This affected approximately 12 students and
reduced attendance rates to 67% for those weeks.

I raised this with Principal Tan verbally on November 18. He agreed to speak
with the teachers but the conflict continued the following week. I escalated to
Maria on November 25 via email.

**Current status:** Not yet formally resolved. Awaiting written directive from
Principal Tan (action item from Q1 review meeting).

### Issue 2 — Coach Absence (Weeks 5–6)

I was ill with a respiratory infection from November 24 to December 5 (two full
weeks). I notified Principal Tan and Maria on the morning of November 24. No
substitute or coverage plan was activated — intervention sessions were simply
cancelled for all groups during my absence.

This resulted in 0% attendance for all School B groups in Weeks 5 and 6.
Combined with the Week 3–4 classroom conflicts, School B Tier 2 students
received only 16 of a planned 24 sessions in the first 8 weeks (67% dosage).

**Recommendation:** A backup protocol is urgently needed. Options: cross-school
coverage (Yolanda covers School B for up to one week if I am absent), or
identification of a trained teacher at School B who can run Tier 2 sessions
in an emergency. Neither is currently in place.

---

## Student Progress Notes

**Tier 2 (K):** Group is making gains but trajectory is behind School A. Given
the two-week interruption, this is expected. Most students are responding to
instruction — the concern is dosage, not instructional quality.

**Tier 3 (K and Grade 1):** Slower progress, as expected for this tier. No
students have exited to Tier 2 yet. Four students (IDs B-K-T3-004, B-K-T3-007,
B-G1-T3-002, B-G1-T3-011) are showing minimal response despite consistent
attendance — flagged for discussion with Maria and possible referral for
evaluation.

---

## Requests for Q2

1. Written backup coverage protocol before January 27
2. Resolution of classroom conflict issue (Principal Tan directive)
3. Guidance on four non-responding students — referral process unclear
4. Access to vocabulary instruction materials for ELL students (flagged in
   literature review as a gap — I am seeing this in practice as well)

---

## Sessions Delivered Summary

| Group | Planned | Delivered | Dosage |
|---|---|---|---|
| B-K-T2 | 24 | 16 | 67% |
| B-K-T3 | 40 | 26 | 65% |
| B-G1-T2 | 24 | 17 | 71% |
| B-G1-T3 | 40 | 27 | 68% |
| **Total** | **128** | **86** | **67%** |
