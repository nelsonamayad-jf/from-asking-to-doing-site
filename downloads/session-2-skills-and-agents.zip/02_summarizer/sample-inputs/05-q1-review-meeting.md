# Q1 Review Meeting — End of Quarter 1
**Date:** January 14, 2027
**Format:** In-person, Regional Office Room 4B
**Facilitator:** Dr. Maria Santos
**Attendees:** Maria Santos, James Okonkwo, Yolanda Pierce (Coach, School A),
Samuel Adeyemi (Coach, School B), Principal Adaora Eze (School A),
Principal Robert Tan (School B), Lena Brandt (funder rep)

---

## Purpose

Review preliminary data from the first 8 weeks of intervention (October 27–
December 19, 2026). Assess whether implementation is on track and identify any
adjustments before Q2 begins.

---

## Summary of Findings Presented

James shared a summary of Weeks 1–8 progress monitoring data:

**School A (Tier 2):** Mean PSF scores for K increased from 28 to 45 over 8 weeks.
Approximately 63% of Tier 2 K students are now at or above benchmark. Grade 1
ORF gains are similar. Strong trajectory.

**School B (Tier 2):** Mean PSF for K increased from 27 to 36 — slower trajectory
than School A. Only 21% of Tier 2 K students at benchmark by week 8. Principal Tan
flagged that attendance in Tier 2 groups at School B has been inconsistent; Yolanda
noted similar concern from Samuel's notes.

**Tier 3 (both schools):** Progress is slower than modeled. Students are gaining
2–3 PSF points per week on average, but very few have reached benchmark in 8 weeks.
This is consistent with the literature on the most intensive cases but will require
extending intervention into Q2 without graduation to Tier 2.

---

## Key Issues Discussed

### 1. Attendance at School B

Samuel reported that Tier 2 group sessions at School B are averaging 78% attendance,
vs. 92% at School A. Primary causes: classroom scheduling conflicts (two teachers
pull students during intervention time for other activities) and a 2-week period in
November when Samuel was out with illness and no substitute coverage was arranged.

**Decision:** Principal Tan to issue a written directive to classroom teachers that
intervention sessions are non-negotiable scheduled time. Attendance data to be
reviewed at next coaching check-in.

### 2. Staffing — Tier 3 Caseload

Actual Tier 3 count at baseline (80 students) confirmed the risk flagged in February.
Yolanda is carrying 35 Tier 3 students; Samuel is carrying 45. Both coaches report
that daily 1:1 sessions are not feasible at this caseload — they are running sessions
in pairs (1:2), which is not fully aligned with IES recommendations for Tier 3.

Maria confirmed a budget amendment request has been submitted to the Regional
Education Fund to hire a part-time third coach. Decision expected by February 2027.

**Lena (funder) note:** Budget amendment is under review and will likely be approved
but cannot be confirmed on this call. She encouraged the team to document the
caseload issue clearly in the Q1 funder report.

### 3. Q1 Funder Report

Due October 30 — *missed.* Submitted December 5 after delay (acknowledged in
email to Lena on December 1). Maria apologized and confirmed Q2 report will be
submitted on time (due January 30, 2027).

---

## Decisions

1. Principal Tan to issue attendance directive — by January 21
2. Tier 3 pairs (1:2) accepted as interim model pending third coach decision
3. Q2 funder report due January 30 — Maria responsible

---

## Action Items

| Item | Owner | Due |
|---|---|---|
| Attendance directive to teachers | Principal Tan | Jan 21 |
| Third coach hiring update | Maria | Feb meeting |
| Q2 funder progress report | Maria | Jan 30 |
| Week 9–16 data collection plan | James | Jan 21 |

---

## Next Meeting

February 11, 2027 — virtual
Focus: Q2 data plan, third coach update, mid-year assessment preparation
