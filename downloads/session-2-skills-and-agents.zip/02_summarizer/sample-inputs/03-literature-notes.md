# Literature and Evidence Review Notes
**Compiled by:** Maria Santos  
**Date:** January 20, 2026  
**Purpose:** Key evidence base for project design and evaluation framing

---

## Core Evidence: Structured Literacy and the Science of Reading

### 1. National Reading Panel (2000)
**Full citation:** National Institute of Child Health and Human Development (2000).
*Report of the National Reading Panel: Teaching children to read.* Washington, DC: NICHD.

**Key findings:**
- Systematic phonics instruction produces significant benefits for early reading
- Phonemic awareness instruction is effective when taught explicitly and systematically
- Fluency instruction improves reading comprehension
- Vocabulary and comprehension strategies are essential complements

**Methodological note:** Systematic review of 100,000+ studies; widely considered
the foundational evidence base for structured literacy. Criticized for excluding
some study designs (no consensus-only approach), but core findings have been
replicated consistently.

**Implication for project:** Justifies the structured literacy PD model.
DIBELS measures the skills (phonemic awareness, fluency) shown to be causal.

---

### 2. Hernandez (2011) — Third Grade Reading and Graduation
**Full citation:** Hernandez, D.J. (2011). *Double jeopardy: How third-grade reading
skills and poverty influence high school graduation.* Annie E. Casey Foundation.

**Key finding:** Students who cannot read proficiently by end of third grade are
4× more likely not to graduate high school. For students in poverty who cannot read
by third grade, the rate is 13× higher than for proficient, non-poor peers.

**Implication for project:** Core justification for investing in early intervention.
Use this statistic in the proposal narrative and presentations.

**Caveat:** Correlational study. Poverty is a major confound — these are not
pure reading effect estimates.

---

### 3. Wanzek et al. (2013) — Intensive Reading Intervention Effects
**Full citation:** Wanzek, J., Wexler, J., Vaughn, S., & Ciullo, S. (2013).
Reading interventions for struggling readers in the upper elementary grades:
A synthesis of 20 years of research. *Reading and Writing, 23*(8), 889–912.

**Key finding:** Intensive interventions (daily, small group, structured) produce
significant improvements in word reading (d = 0.58) and comprehension (d = 0.34)
for struggling readers in Grades 3–5.

**Methodological note:** Meta-analysis of 22 studies; effect sizes are moderate
and meaningful but smaller than early intervention effects.

**Implication for project:** Supports Tier 2 and 3 group sizes (3–5 students)
and frequency (3–5 sessions/week). Note that our target is earlier (K–1),
where effects tend to be larger.

---

### 4. Gersten et al. (2008) — IES Practice Guide on RTI
**Full citation:** Gersten, R., Compton, D., Connor, C.M., et al. (2008).
*Assisting students struggling with reading: Response to Intervention and
multi-tier intervention for reading in the primary grades.* IES Practice Guide.
Washington, DC: NCEE.

**Key recommendations (relevant to this project):**
- Universal screening at least 3× per year (aligned with our design)
- Tier 2: small group (3–5), 3–4 sessions per week, 20–40 minutes
- Tier 3: daily, individualized or very small group (1–3 students)
- Progress monitoring every 2–4 weeks for Tier 2; weekly for Tier 3
- Data-based decision making at 6–8 week intervals

**Strength of evidence:** Strong (based on randomized controlled trials and
quasi-experimental designs). IES Practice Guide — highest ESSA tier.

**Implication for project:** Our design is aligned with these recommendations.
The progress monitoring frequency is one area to strengthen — our protocol
currently specifies "quarterly" (3×/year), which meets the universal screening
standard but may not be sufficient for Tier 3 students who need weekly monitoring.

⚠ **Flag:** Gap between IES recommendation (weekly PM for Tier 3) and our
current protocol (3× per year). This needs to be addressed.

---

### 5. ELL-specific note: Baker et al. (2014)
**Full citation:** Baker, S., Lesaux, N., Jayanthi, M., et al. (2014).
*Teaching academic content and literacy to English learners in elementary and middle school.*
IES Practice Guide. Washington, DC: NCEE.

**Relevant to School B's ELL population:**
- Explicit vocabulary instruction is particularly important for ELL students
- Structured literacy approaches (phonics, fluency) are effective for ELL students
  and should not be withheld pending English oral proficiency development
- Oral language development should be integrated into literacy instruction

**Implication for project:** Reinforces use of IDEL (Spanish) for ELL students at
School B while maintaining structured literacy approach. Also flags vocabulary
as a component we have not built into Tier 2 intervention — worth discussing with RTTI.

---

## Summary: Evidence Gaps in Our Design

Based on this review, two gaps are worth flagging:

1. **Progress monitoring frequency for Tier 3:** IES recommends weekly; our
   design specifies 3×/year screening. These serve different purposes, but
   we should add a progress monitoring protocol for Tier 3 students.

2. **Vocabulary instruction for ELL students:** Baker et al. highlight this as
   a high-priority addition for ELL contexts. School B's demographics (42% ELL)
   make this particularly relevant — but it is not currently in scope.

These are not showstoppers, but they should be documented as known limitations
and potentially addressed in the implementation guide.
