# Baseline Screening Results — Summary Data
**Source:** DIBELS 8th Edition screening, fall administration  
**Schools:** School A and School B  
**Date of administration:** October 6–10, 2026  
**Data compiled by:** James Okonkwo, Data Coordinator  
**Report date:** October 24, 2026

---

## Overview

A total of 487 students in kindergarten and first grade were screened
across the two project schools. This represents 96% of the enrolled
student population in target grades; 21 students were absent or had
parent opt-out forms on file.

---

## Kindergarten Results

### Phonemic Awareness (PSF — Phoneme Segmentation Fluency)

| Category | School A | School B | Combined |
|---|---|---|---|
| At or above benchmark | 61% | 53% | 57% |
| Some risk (below 25th pct) | 24% | 28% | 26% |
| At risk (below 10th pct) | 15% | 19% | 17% |
| Total screened | 134 | 118 | 252 |

**Benchmark score:** 40+ phonemes per minute

School A mean PSF: 47.2 (SD = 18.6)  
School B mean PSF: 43.1 (SD = 21.2)

### Letter Naming Fluency (LNF)

| Category | School A | School B | Combined |
|---|---|---|---|
| At or above benchmark | 58% | 49% | 54% |
| Some risk | 27% | 31% | 29% |
| At risk | 15% | 20% | 17% |

School B's lower LNF scores are partially explained by the higher proportion
of ELL students (42%) who are still acquiring English letter recognition.

---

## First Grade Results

### Oral Reading Fluency (ORF — Words Correct Per Minute)

Note: IDEL (Spanish) was used for 38 ELL students at School B following
authorization received November 1 (see correspondence files). These scores
were converted to ORF equivalents using published norms.

| Category | School A | School B | Combined |
|---|---|---|---|
| At or above benchmark | 64% | 55% | 60% |
| Some risk (below 25th pct) | 22% | 25% | 23% |
| At risk (below 10th pct) | 14% | 20% | 17% |
| Total screened | 121 | 114 | 235 |

**Benchmark:** 23+ words correct per minute (end of fall, Grade 1)

School A mean ORF: 28.4 wcpm (SD = 14.1)  
School B mean ORF: 25.7 wcpm (SD = 16.8)

---

## Tier Assignment Summary

Based on screening results, students were assigned to intervention tiers:

| Tier | Criteria | School A | School B | Total |
|---|---|---|---|---|
| Tier 1 only | At or above benchmark | 156 | 126 | 282 |
| Tier 2 | Below 25th percentile | 101 | 84 | 185 |
| Tier 3 | Below 10th percentile | 35 | 45 | 80 |
| Not screened | Absent / opt-out | 12 | 9 | 21 |
| **Total enrolled** | | **304** | **264** | **568** |

⚠ **Note:** Tier 3 numbers (80 students) significantly exceed original
project projections (estimated 50–60 Tier 3 students based on 10% of
2,400/2 = 240 students per cohort). This has implications for staffing —
two reading coaches may be insufficient to provide daily individual
sessions for 80 students while also running Tier 2 groups.

---

## Comparison to Historical Baseline

The proposal referenced 38% at grade level among first-graders from
low-income households in the region. Our Tier 3 rate (17%) is lower than
expected, but the at-risk definition here uses 10th percentile, not the
"below grade level" threshold used in the regional report. These figures
are not directly comparable.

---

## Data Quality Notes

- 21 missing observations (4.3% of enrolled) due to absence and opt-out
- School A data entered within 5 days of screening; School B data delayed
  12 days due to device access issues (see meeting notes from January)
- One classroom at School A (22 students) used paper forms — data entered
  by James; no systematic errors found on review
- IDEL-to-ORF conversion for ELL students uses 2019 norming study;
  more recent norms not yet available
