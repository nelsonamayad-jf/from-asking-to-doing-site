# Project Kickoff Meeting Notes
**Date:** January 15, 2026  
**Location:** Regional Office, Room 4B  
**Facilitator:** Dr. Maria Santos  
**Attendees:** Maria Santos (Project Director), James Okonkwo (Data Coordinator),
Principal Adaora Eze (School A), Principal Robert Tan (School B),
Fatima Al-Rashid (Regional Teacher Training Institute), Lena Brandt (funder rep, observer)

---

## Agenda

1. Project overview and objectives recap
2. School readiness and site preparation
3. Timeline and first milestones
4. Data systems and screening logistics
5. Questions and concerns

---

## Discussion Notes

### 1. Project Overview

Maria opened by reminding all parties that the project's primary goal is
to demonstrate a replicable model — not just improve outcomes at these
two schools, but document what works so other districts can adopt it.
Lena (funder) confirmed this is a priority for the Regional Education Fund.

### 2. School Readiness

**School A (Principal Eze):**
- Staff are generally enthusiastic, but 3 teachers have expressed concerns
  about workload — they feel PD schedule on top of regular duties is too heavy
- Request to shift Phase 1 PD from weekday afternoons to Saturday mornings
- Space is available for small-group Tier 2 intervention sessions
- Data system: school currently uses a legacy SIS that may not integrate
  easily with the new screening dashboard — IT department needs to be looped in

**School B (Principal Tan):**
- Strong buy-in from staff — principal has already briefed teachers twice
- One complication: School B serves a higher proportion of ELL students
  than originally anticipated (42% vs. 32% in the proposal)
- Request for DIBELS materials to be available in Spanish — Maria committed
  to checking whether IDEL (Spanish equivalent) can be substituted for ELL students
- No space issues; a dedicated intervention room is available

### 3. Timeline

First milestone: baseline DIBELS screening in fall (Month 4 = October 2026).
James noted that teacher training on how to administer DIBELS must happen
before October — proposed a half-day admin training in September.

**Decision made:** Add a half-day screening administration training in
September (Month 3), not currently in the project plan. Fatima (RTTI)
will incorporate this into Phase 1 PD design.

**Action item:** James to send updated timeline to all by January 22.

### 4. Data Systems

James presented the proposed dashboard structure. Key features:
- Automatic flagging of students below 25th and 10th percentiles
- Teacher-level and school-level views
- Export function for external reporting

**Issue raised:** Principal Eze flagged that teachers may not have reliable
device access for data entry. Some classrooms share a single iPad.
Decision: James will investigate whether paper-based data collection with
delayed entry is feasible as a fallback.

**Action item:** James to report back on device access issue by January 29.

### 5. Concerns and Open Questions

- **ELL accommodation:** Maria to confirm whether IDEL substitution is allowed
  under DIBELS licensing by February 1. This is a blocking issue for School B.
- **PD scheduling:** Fatima will draft revised Phase 1 PD schedule with
  Saturday option included. Due February 5.
- **Funder reporting:** Lena reminded the team that quarterly progress reports
  are due 30 days after each quarter ends. First report due October 30, 2026.

---

## Action Items Summary

| Item | Owner | Due |
|---|---|---|
| Send updated project timeline | James | Jan 22 |
| Confirm IDEL/DIBELS ELL accommodation | Maria | Feb 1 |
| Revised Phase 1 PD schedule (Sat option) | Fatima (RTTI) | Feb 5 |
| Device access feasibility for data entry | James | Jan 29 |
| Loop in School A IT on dashboard integration | Principal Eze | Feb 1 |

---

## Next Meeting

February 12, 2026 — virtual, 10am–11:30am  
Focus: PD schedule finalization and dashboard demo
