---
name: report
description: "Assemble the Session 2 summaries into a formatted .docx report."
---

# /report

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/report.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Pause for human confirmation before writing the final report.
