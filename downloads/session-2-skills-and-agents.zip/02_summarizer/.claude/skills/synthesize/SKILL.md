---
name: synthesize
description: "Read the Session 2 manifest and create one structured summary per input file."
---

# /synthesize

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/synthesize.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Require `output/manifest.md` before proceeding.
