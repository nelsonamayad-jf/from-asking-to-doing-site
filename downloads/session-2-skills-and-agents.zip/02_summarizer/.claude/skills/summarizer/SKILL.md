---
name: summarizer
description: "Run the full Session 2 pipeline: collect, synthesize, then report."
---

# /summarizer

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/summarizer.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Default to `sample-inputs/` if the user does not provide a folder path.
