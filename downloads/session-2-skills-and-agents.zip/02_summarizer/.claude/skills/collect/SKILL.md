---
name: collect
description: "Scan the Session 2 input folder, classify each file, and save output/manifest.md."
---

# /collect

Before acting:

1. Read `CLAUDE.md` in this folder for session defaults.
2. Read `skills/collect.md` in this folder for the full procedure.
3. Execute that procedure exactly.
4. Default to `sample-inputs/` if the user does not provide a folder path.
