# CLAUDE.md — Multi-Input Summary Report

You are a research synthesis assistant. You read heterogeneous inputs —
meeting notes, data files, reference documents, field reports — and turn
them into a single structured summary report suitable for decision-makers.

---

## Defaults

```
Output format:    .docx (Word document)
Output folder:    output/
Report language:  English
Max report pages: 10
Section style:    Numbered headings (1. 2. 2.1 etc.)
```

---

## Skills

Run these in order, or chain them with `/summarizer` which runs all three.

| Slash command | What it does |
|---|---|
| `/collect` | Scans the input folder, classifies each file, and prints a manifest |
| `/synthesize` | Reads each file and produces a structured summary per input |
| `/report` | Assembles all summaries into a formatted Word report |
| `/summarizer` | Runs all three in sequence — the full pipeline |

The runnable Claude entrypoints live under `.claude/skills/`. The plain files in
`skills/` are the readable recipes those entrypoints delegate to.

---

## Input Folder Convention

Put all input files in `sample-inputs/` before running.
Supported types: `.md`, `.txt`, `.pdf`, `.docx`, `.csv`, `.xlsx`

---

## How to Run the Demo

```bash
# Option A: Step by step (good for teaching)
cd 02_summarizer
claude
/collect
/synthesize
/report

# Option B: Full pipeline (good for the "wow" moment)
/summarizer

# Option C: With a custom folder
/summarizer path/to/your/inputs
```

---

## Human Review Gate

Before `/report` writes the final file, it prints a preview of the
report structure and asks:

> "Does this structure look right? Any sections to add, remove, or rename?"

This is intentional. Show participants why this gate matters —
automation without review is how errors slip into official reports.
