# Session 2 · Skills and Agents

Turn a mixed folder of files into one decision-ready summary report.

## Open This Folder

Use this folder as a standalone project in Claude or Codex:

- Claude: `02_summarizer/CLAUDE.md`
- Codex: `02_summarizer/AGENTS.md`
- Runnable Claude skills: `02_summarizer/.claude/skills/`

The website deck source for this session lives under `website/02_summarizer/`.
It is separate on purpose and is not needed to replicate the session.

## Quickstart

Claude:

```text
/summarizer
```

or, step by step:

```text
/collect
/synthesize
/report
```

Codex:

```text
Read CLAUDE.md and skills/summarizer.md, then run the collect → synthesize → report pipeline over sample-inputs/, pausing before the final report to confirm the structure. Save all outputs under output/.
```

## Important Folders

- `sample-inputs/` — the default classroom dataset
- `output/` — manifest, summaries, and final report
- `skills/` — readable recipes for each pipeline step
- `.claude/skills/` — Claude slash-command entrypoints

## Expected Output

- `output/manifest.md`
- `output/summaries/`
- `output/summary-report.docx`
