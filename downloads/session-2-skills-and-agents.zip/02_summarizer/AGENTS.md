# AGENTS.md — Session 2 · Skills and Agents

This folder is meant to run standalone in Codex.

Before taking action:

1. Read `CLAUDE.md` in this folder and use it as the session contract.
2. Read the relevant file in `skills/` for the step the user wants to run.

Working defaults:

- Default input folder: `sample-inputs/`
- Output folder: `output/`
- Pipeline order: collect → synthesize → report
- Pause for human confirmation before writing the final report

If the user asks for the exact classroom flow, prefer the full `/summarizer` pipeline semantics from `skills/summarizer.md`.
